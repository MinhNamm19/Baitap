
function addMoviefileValidation(){
    var fileInput = document.getElementById('img');
    var fileInput_bg = document.getElementById('img-bg');
    var tenphim = document.getElementById('ten-phim');
    var tenphimkhac = document.getElementById('ten-phim-khac');
    var noidung = document.getElementById('noidung');
    var filePath = fileInput.value; 
    var filePath_bg = fileInput_bg.value; 
    var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;//các tập tin cho phép
    
    if( tenphim.value === "" && tenphimkhac.value === "" && noidung.value === "" ){
        var erro = document.getElementById('popup');
        erro.innerHTML = "Vui lòng nhập đầy đủ thông tin";
        return false;
    }
    // Kiểm tra định dạng
    if(!allowedExtensions.exec(filePath) || !allowedExtensions.exec(filePath_bg)){
        var erro = document.getElementById('popup');
        erro.innerHTML = "Vui lòng upload các file có định dạng: .jpeg .jpg .png ";
        return false;
    }
  
    return true;
}

function getContent(ele){
    const id = ele.getAttribute("data-id");
    $.get("pages/news/get_content.php", {idTinTuc:id}, function(data){
        $("#noidung").html(data);
    });
    document.getElementById('view-content').style.display='block';
}

////
function showTheLoaiPhim(ele){
    const id = ele.getAttribute("data-idphim");
    $.get("pages/movie/theloai_phim.php", {idPhim:id}, function(data){
        $("#theloai-phim").html(data);
    });
    document.getElementById('theloai-phim').style.display='block';
}

function deleteTheLoaiPhim(ele){
    const id = ele.getAttribute("data-id");
    const action = ele.getAttribute("data-action");
    const idtp = ele.getAttribute("data-idtp");
    $.get("pages/movie/theloai_phim.php", {idPhim:id, idTP:idtp, action:action}, function(data){
        $("#theloai-phim").html(data);
    });
}

function addTheLoaiPhim(ele){
    const idTL = ele.getAttribute("data-idtl");
    const action = ele.getAttribute("data-action");
    const idPhim = ele.getAttribute("data-idphim");
    $.get("pages/movie/theloai_phim.php", {idPhim:idPhim, idTL:idTL, action:action}, function(data){
        $("#theloai-phim").html(data);
    });
    document.getElementById('theloai').style.display='none';
    document.getElementById('theloai-phim').style.display='block';
}

function showTheLoai(ele){
    const idPhim = ele.getAttribute("data-idphim");
    $.get("pages/movie/add_theloai_phim.php", {idPhim:idPhim}, function(data){
        $("#theloai").html(data);
    });
    document.getElementById('theloai-phim').style.display='none';
    document.getElementById('theloai').style.display='block';
}
function rtTheLoai(){
    document.getElementById('theloai').style.display='none';
    document.getElementById('theloai-phim').style.display='block';
}

function showSeriesPhim(ele){
    const idPhim = ele.getAttribute("data-id");
    $.get("pages/movie/add_series_phim.php", {idPhim:idPhim}, function(data){
        $("#series-phim").html(data);
    });
    document.getElementById('series-phim').style.display='block';
}
function addSea(ele){
    const idPhim = ele.getAttribute("data-idphim");
    const idSR = ele.getAttribute("data-idsr");
    document.getElementById('series-phim').style.display='none';
    document.getElementById('add-season').style.display='block';
    const btnAdd = document.getElementById("btn-add-sea");
    btnAdd.setAttribute("data-idphim", idPhim);
    btnAdd.setAttribute("data-series", idSR);
    
}

function addSeasonPhim(ele){
    const sea = document.getElementById("season").value;
    const idSeries = ele.getAttribute("data-series");
    const action = ele.getAttribute("data-action");
    const idPhim = ele.getAttribute("data-idphim");
    $.get("pages/movie/season_phim.php", {idPhim:idPhim, idSeri:idSeries, season:sea, action:action}, function(data){
        $("#season-phim").html(data);
    });
    document.getElementById('add-season').style.display='none';
    document.getElementById('season-phim').style.display='block';
}

function showSeason(ele){
    const idPhim = ele.getAttribute("data-idphim");
    $.get("pages/movie/season_phim.php", {idPhim:idPhim}, function(data){
        $("#season-phim").html(data);
    });
    document.getElementById('season-phim').style.display='block';
}

function addEpisode(ele){
    const idPhim = ele.getAttribute("data-idphim");
    const idServer = ele.getAttribute("data-idserver");
    $.get("pages/episode/add_ep.php", {idPhim:idPhim, idServer:idServer}, function(data){
        $("#add-episode").html(data);
    });
    document.getElementById('add-episode').style.display='block';
}

function viewEpisode(ele){
    const idEp = ele.getAttribute("data-idep");
    $.get("pages/episode/view_ep.php", {idEp:idEp}, function(data){
        $("#view-episode").html(data);
    });
    document.getElementById('view-episode').style.display='block';
}

function viewVideo(ele){
    const Url = ele.getAttribute("data-url");
    const idServer = ele.getAttribute("data-idserver");
    $.get("../user_action/change_server.php", {url:Url, server:idServer}, function(data){
        $("#iframe").html(data);
    });
    document.getElementById('iframe').style.display='block';
}

function suaTheLoai(ele){
    const idTL = ele.getAttribute("data-idtl");
    $.get("pages/theloai/sua_theloai.php", {idTL:idTL}, function(data){
        $("#sua-theloai").html(data);
    });
    document.getElementById('sua-theloai').style.display='block';
}

function suaServer(ele){
    const idServer = ele.getAttribute("data-idserver");
    $.get("pages/server/sua_server.php", {idServer:idServer}, function(data){
        $("#sua-server").html(data);
    });
    document.getElementById('sua-server').style.display='block';
}

function suaSeries(ele){
    const idSeries = ele.getAttribute("data-idseries");
    $.get("pages/series/sua_series.php", {idSeries:idSeries}, function(data){
        $("#sua-series").html(data);
    });
    document.getElementById('sua-series').style.display='block';
}

function showPhimSeri(ele){
    const idSeries = ele.getAttribute("data-idseries");
    $.get("pages/series/show_phim_series.php", {idSeries:idSeries}, function(data){
        $("#phim-series").html(data);
    });
    document.getElementById('phim-series').style.display='block';
}

function showListMovie(ele){
    const idSeries = ele.getAttribute("data-idseries");
    $.get("pages/series/list_phim.php", {idSeries:idSeries}, function(data){
        $("#list-phim").html(data);
    });
    document.getElementById('list-phim').style.display='block';
}

function addPhimSeriFS(ele){
    const idSeries = ele.getAttribute("data-idseries");
    const idPhim = ele.getAttribute("data-idphim");
    $.get("pages/series/add_phim_series.php", {idSeries:idSeries, idPhim:idPhim}, function(data){
        $("#add-phim-series").html(data);
    });
    document.getElementById('list-phim').style.display='none';
    document.getElementById('add-phim-series').style.display='block';
}

function suaNam(ele){
    const idNam = ele.getAttribute("data-idnam");
    $.get("pages/years/sua_nam.php", {idNam:idNam}, function(data){
        $("#sua-nam").html(data);
    });
    document.getElementById('sua-nam').style.display='block';
}

function showListPhim(ele){
    const idSlide = ele.getAttribute("data-idslide");
    $.get("pages/slide/sua_slide.php", {idSlide:idSlide}, function(data){
        $("#sua-slide").html(data);
    });
    document.getElementById('sua-slide').style.display='block';
}

function changeType(ele){
    const idUser = ele.getAttribute("data-iduser");
    $.get("pages/user/sua_user.php", {idUser:idUser}, function(data){
        $("#sua-loai").html(data);
    });
    document.getElementById('sua-loai').style.display='block';
}