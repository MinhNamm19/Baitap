<?php
require 'function.php';
require "../dbcon/ConDB.php";
    if( isset($_POST["add"])){
        if($_POST["danhmuc"] !== ""){
            $danhmuc = $_POST["danhmuc"];
            $check = "
                SELECT idDanhMuc FROM tb_danhmuc
                WHERE DanhMuc = :danhmuc;
            ";
            $pre = $conn->prepare($check);
            $pre->bindParam(":danhmuc", $danhmuc, PDO::PARAM_STR);
            $pre->execute();
            $count = $pre->rowCount();
            if($count === 0){
                $sql = "
                    INSERT INTO tb_danhmuc (idDanhMuc, DanhMuc) 
                    VALUES (NULL, :danhmuc)
                ";
                $pre = $conn->prepare($sql);
                $pre->bindParam(":danhmuc", $danhmuc, PDO::PARAM_STR);
                $pre->execute();
                header("location:../?p=show-danhmuc");
            }else{
                echo "<script> window.history.back(); </script>";
                echo "<script> alert('Danh mục đã tồn tại'); </script>";
            }
        }else {
            echo "<script> window.history.back(); </script>";
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["xoa"])){
        $idDanhMuc = filter_input(INPUT_POST, 'idDanhMuc');
        $check = "
                SELECT idDanhMuc FROM tb_loaitin
                WHERE idDanhMuc = :idDanhMuc;
            ";
            $pre = $conn->prepare($check);
            $pre->bindParam(":idDanhMuc", $idDanhMuc, PDO::PARAM_INT);
            $pre->execute();
            $count = $pre->rowCount();
        
        if($count == 0){
            $sql = "
                DELETE FROM tb_danhmuc
                WHERE idDanhMuc = :idDanhMuc
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idDanhMuc", $idDanhMuc, PDO::PARAM_INT);
            $pre->execute();
            header("location:../?p=show-danhmuc");
        }else{
            echo "<script> window.history.back(); </script>";
            echo "<script> alert('Chắc cmm à ???'); </script>";
        }
    }
?>