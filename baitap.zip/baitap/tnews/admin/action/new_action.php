<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$date = date("Y-m-d H:i:s");
require 'function.php';
require "../dbcon/ConDB.php";
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$expensions= array("jpeg","jpg","png");
    if( isset($_POST["add"])){
        
        if( !empty($_POST["tieude"]) && !empty($_POST["noidung"])){
            $tieude = $_POST["tieude"];
            $tieudekd = changeTitle($tieude);
            $noidung = $_POST["noidung"];
            $luotxem = $_POST["luotxem"];
            $anh = $_FILES['img']['name'];
            $loaitin = $_POST["loaitin"];
            $nguontin = $_POST["nguontin"];
            $user = $_POST["idUser"];
            $duoi = pathinfo($anh, PATHINFO_EXTENSION);
            $check = "
                SELECT idTinTuc FROM tb_tintuc
                WHERE TieuDe = :TieuDe;
            ";
            $pre = $conn->prepare($check);
            $pre->bindParam(":TieuDe", $tieude, PDO::PARAM_STR);
            $pre->execute();
            $count = $pre->rowCount();
            if($count === 0){
                
                if( in_array($duoi, $expensions) === TRUE ){
                
                    $anhminhoa = $tieudekd."-".substr(str_shuffle($permitted_chars), 0, 5).".".$duoi;
                    while(file_exists("../../public/img/news/".$anhminhoa)){
                        $anhminhoa = $tieudekd."-".substr(str_shuffle($permitted_chars), 0, 5).".".$duoi;
                    }
                    move_uploaded_file($_FILES['img']['tmp_name'], "../../public/img/news/".$anhminhoa);
                    $sql = "
                        INSERT INTO 
                        tb_tintuc (idTinTuc, TieuDe, TieuDeKD, NoiDung, AnhMH, NgayDang, LuotXem, idLoaiTin, idNguonTin, idUser) 
                        VALUES 
                        (NULL, :tieude, :tieudekd, :noidung, :anhminhoa, :date, :luotxem, :loaitin, :nguontin, :user);
                    ";
                    $pre = $conn->prepare($sql);
                    $pre->bindParam(":tieude", $tieude, PDO::PARAM_STR);
                    $pre->bindParam(":tieudekd", $tieudekd, PDO::PARAM_STR);
                    $pre->bindParam(":noidung", $noidung, PDO::PARAM_STR);
                    $pre->bindParam(":anhminhoa", $anhminhoa, PDO::PARAM_STR);
                    $pre->bindParam(":luotxem", $luotxem, PDO::PARAM_INT);
                    $pre->bindParam(":loaitin", $loaitin, PDO::PARAM_INT);
                    $pre->bindParam(":nguontin", $nguontin, PDO::PARAM_INT);
                    $pre->bindParam(":user", $user, PDO::PARAM_INT);
                    $pre->bindParam(":date", $date, PDO::PARAM_STR);
                    $pre->execute();
                    header("location:../?p=show-news");
                }else{
                    echo "<script> alert('Chỉ nhận file ảnh'); </script>";
                }
            }else{
                echo "<script> alert('Tin đã tồn tại'); </script>";
            }
        }else {
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["sua"])){
        if( !empty($_POST["tieude"]) && !empty($_POST["noidung"])){
            $idTin = $_POST["id"];
            $tieude = $_POST["tieude"];
            $tieudekd = changeTitle($tieude);
            $noidung = $_POST["noidung"];
            $luotxem = $_POST["luotxem"];
            $loaitin = $_POST["loaitin"];
            $nguontin = $_POST["nguontin"];
            $anhminhhoa = $_POST["anhmh"];

            if( $_FILES["img"]['name'] !== "" ){
                $anh = $_FILES['img']['name'];
                $duoi = pathinfo($anh, PATHINFO_EXTENSION);
                $anhmh = $tieudekd."-".substr(str_shuffle($permitted_chars), 0, 5).".".$duoi;
                while(file_exists("../../public/img/news/".$anhmh)){
                    $anhmh = $tieudekd."-".substr(str_shuffle($permitted_chars), 0, 5).".".$duoi;
                }
                move_uploaded_file($_FILES['img']['tmp_name'], "../../public/img/news/".$anhmh);
                unlink("../../public/img/news/".$anhminhhoa);
                $img = "AnhMH = "."'$anhmh'".",";
            }else{
                $img = "";
            }

            $sql = "
                UPDATE tb_tintuc
                SET ".$img."
                    TieuDe =  :tieude,
                    TieuDeKD = :tieudekd,
                    NoiDung = :noidung,
                    LuotXem = :luotxem,
                    idLoaiTin =  :loaitin,
                    idNguonTin = :nguontin
                WHERE idTinTuc = :idTin;
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":tieude", $tieude, PDO::PARAM_STR);
            $pre->bindParam(":tieudekd", $tieudekd, PDO::PARAM_STR);
            $pre->bindParam(":noidung", $noidung, PDO::PARAM_STR);
            $pre->bindParam(":luotxem", $luotxem, PDO::PARAM_INT);
            $pre->bindParam(":loaitin", $loaitin, PDO::PARAM_INT);
            $pre->bindParam(":nguontin", $nguontin, PDO::PARAM_INT);
            $pre->bindParam(":idTin", $idTin, PDO::PARAM_INT);
            $pre->execute();
            header("location:../?p=sua-new&idTinTuc=".$idTin);
        }else {
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["xoa"])){
        $id = filter_input(INPUT_POST, 'idTinTuc');
        $img = $_POST["img"];
        $sql = "
            DELETE FROM tb_tintuc
            WHERE idTinTuc = :idTinTuc
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":idTinTuc", $id, PDO::PARAM_INT);
        $pre->execute();
        unlink("../../public/img/news/".$img);
        header("location:../?p=show-news");
    }
?>