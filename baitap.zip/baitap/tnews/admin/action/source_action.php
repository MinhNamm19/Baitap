<?php
require 'function.php';
require "../dbcon/ConDB.php";
    if( isset($_POST["add"])){
        if($_POST["nguontin"] !== ""){
            $nguontin = $_POST["nguontin"];
            $check = "
                SELECT idNguonTin FROM tb_nguontin
                WHERE NguonTin = :nguontin;
            ";
            $pre = $conn->prepare($check);
            $pre->bindParam(":nguontin", $nguontin, PDO::PARAM_STR);
            $pre->execute();
            $count = $pre->rowCount();
            if($count === 0){
                $sql = "
                    INSERT INTO tb_nguontin (idNguonTin, NguonTin) 
                    VALUES (NULL, :nguontin)
                ";
                $pre = $conn->prepare($sql);
                $pre->bindParam(":nguontin", $nguontin, PDO::PARAM_STR);
                $pre->execute();
                header("location:../?p=show-source");
            }else{
                echo "<script> window.history.back(); </script>";
                echo "<script> alert('Nguồn tin đã tồn tại'); </script>";
            }
        }else {
            echo "<script> window.history.back(); </script>";
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["xoa"])){
        $idNguonTin = filter_input(INPUT_POST, 'idNguonTin');
        $sql = "
            DELETE FROM tb_nguontin
            WHERE idNguonTin = :idNguonTin
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":idNguonTin", $idNguonTin, PDO::PARAM_INT);
        $pre->execute();
        header("location:../?p=show-source");
    }
?>