<?php
require 'function.php';
require "../dbcon/ConDB.php";
    if( isset($_POST["sua-loai"])){
        $idUser = filter_input(INPUT_POST, 'idUser');
        $idLoai = filter_input(INPUT_POST, 'idLoai');
        $sql = "
            UPDATE tb_user
            SET idLoaiTK = :idLoai
            WHERE idUser = :idUser
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":idUser", $idUser, PDO::PARAM_INT);
        $pre->bindParam(":idLoai", $idLoai, PDO::PARAM_INT);
        $pre->execute();
        header("location:../?p=show-users");
    }
    if( isset($_POST["xoa"])){
        $idUser = filter_input(INPUT_POST, 'idUser');
        $sql = "
            DELETE FROM tb_user
            WHERE idUser = :idUser
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":idUser", $idUser, PDO::PARAM_INT);
        $pre->execute();
        header("location:../?p=show-users");
    }
?>