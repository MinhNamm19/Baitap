<?php
require 'function.php';
require "../dbcon/ConDB.php";
    if( isset($_POST["add"])){
        if($_POST["loaitin"] !== ""){
            $loaitin = $_POST["loaitin"];
            $loaitinkd = changeTitle($loaitin);
            $danhmuc = $_POST["danhmuc"];
            $check = "
                SELECT idLoaiTin FROM tb_loaitin
                WHERE LoaiTin = :loaitin;
            ";
            $pre = $conn->prepare($check);
            $pre->bindParam(":loaitin", $loaitin, PDO::PARAM_STR);
            $pre->execute();
            $count = $pre->rowCount();
            if($count === 0){
                $sql = "
                    INSERT INTO tb_loaitin (idLoaiTin, LoaiTin, LoaiTinKD, idDanhMuc) 
                    VALUES (NULL, :loaitin, :loaitinkd, :danhmuc)
                ";
                $pre = $conn->prepare($sql);
                $pre->bindParam(":loaitin", $loaitin, PDO::PARAM_STR);
                $pre->bindParam(":loaitinkd", $loaitinkd, PDO::PARAM_STR);
                $pre->bindParam(":danhmuc", $danhmuc, PDO::PARAM_INT);
                $pre->execute();
                header("location:../?p=show-kinds");
            }else{
                echo "<script> window.history.back(); </script>";
                echo "<script> alert('Loại tin đã tồn tại'); </script>";
            }
        }else {
            echo "<script> window.history.back(); </script>";
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["xoa"])){
        $idLoaiTin = filter_input(INPUT_POST, 'idLoaiTin');
        $sql = "
            DELETE FROM tb_loaitin
            WHERE idLoaiTin = :idLoaiTin
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":idLoaiTin", $idLoaiTin, PDO::PARAM_INT);
        $pre->execute();
        header("location:../?p=show-kinds");
    }
?>