<?php
require 'function.php';
require "../dbcon/ConDB.php";
    if( isset($_POST["add"])){
        if($_POST["tu"] !== ""){
            $tu = $_POST["tu"];
            $check = "
                SELECT idLoaius FROM tb_loaiuser
                WHERE Loai = :tu;
            ";
            $pre = $conn->prepare($check);
            $pre->bindParam(":tu", $tu, PDO::PARAM_STR);
            $pre->execute();
            $count = $pre->rowCount();
            if($count === 0){
                $sql = "
                    INSERT INTO tb_loaiuser (idLoaius, Loai) 
                    VALUES (NULL, :tu)
                ";
                $pre = $conn->prepare($sql);
                $pre->bindParam(":tu", $tu, PDO::PARAM_STR);
                $pre->execute();
                header("location:../?p=show-user-tu");
            }else{
                echo "<script> window.history.back(); </script>";
                echo "<script> alert('Loại người dùng đã tồn tại'); </script>";
            }
        }else {
            echo "<script> window.history.back(); </script>";
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["sua"])){
        if($_POST["tu"] !== ""){
            $tu = filter_input(INPUT_POST, 'tu');
            $idLoaius = filter_input(INPUT_POST, 'idLoaius');
            $sql = "
                UPDATE tb_loaiuser
                SET Loai = :tu
                WHERE idLoaius = :idLoaius
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":tu", $tu, PDO::PARAM_STR);
            $pre->bindParam(":idLoaius", $idLoaius, PDO::PARAM_INT);
            $pre->execute();
            header("location:../?p=show-user-tu");
        }else {
            echo "<script> window.history.back(); </script>";
            echo "<script> alert('Vui lòng nhập đầy đủ'); </script>";
        }
    }
    if( isset($_POST["xoa"])){
        $idLoaius = filter_input(INPUT_POST, 'idLoaius');
        $sql = "
            DELETE FROM tb_loaiuser
            WHERE idLoaius = :idLoaius
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":idLoaius", $idLoaius, PDO::PARAM_INT);
        $pre->execute();
        header("location:../?p=show-user-tu");
    }
?>