<?php
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    // Tất cả chức năng ở đây

    # Tin tức func
        // Lấy tất cả tin túc
        function all_news(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                INNER JOIN tb_user
                ON tb_tintuc.idUser = tb_user.idUser
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy tất cả tin tức xếp theo lượt xem giảm dần
        function hot_news(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                INNER JOIN tb_user
                ON tb_tintuc.idUser = tb_user.idUser
                ORDER BY LuotXem DESC
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy tin tức có idTinTuc
        function info_new($idTinTuc){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                INNER JOIN tb_user
                ON tb_tintuc.idUser = tb_user.idUser
                WHERE tb_tintuc.idTinTuc = :idTinTuc
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idTinTuc", $idTinTuc, PDO::PARAM_INT);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy tin mới
        function news(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                INNER JOIN tb_user
                ON tb_tintuc.idUser = tb_user.idUser
                ORDER BY idTinTuc DESC
                LIMIT 0, 10
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy 5 tin của loại tin có idLoaitin
        function news_tech($idLoaiTin){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                INNER JOIN tb_user
                ON tb_tintuc.idUser = tb_user.idUser
                WHERE tb_tintuc.idLoaiTin = :idLoaiTin
                ORDER BY idTinTuc DESC
                LIMIT 0, 10
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idLoaiTin", $idLoaiTin, PDO::PARAM_INT);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy 5 tin liên quan mới nhất
        function news_lienquan($idLoaiTin){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                INNER JOIN tb_user
                ON tb_tintuc.idUser = tb_user.idUser
                WHERE tb_tintuc.idLoaiTin = :idLoaiTin
                ORDER BY idTinTuc DESC
                LIMIT 0, 5
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idLoaiTin", $idLoaiTin, PDO::PARAM_INT);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # Danh mục func
        // Lấy tất cả danh mục
        function all_danhmuc(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_danhmuc
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # Loại tin func
        // Lấy tất cả loại tin
        function all_loaitin(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_loaitin
                ORDER BY LoaiTin ASC
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # Nguồn tin func
        // Lấy tất cả nguồn tin
        function all_nguontin(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_nguontin
                ORDER BY NguonTin ASC
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # Slide func
        // Lấy 5 tin mới ra làm slide
        function all_slide(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                ORDER BY tb_tintuc.idTinTuc DESC
                LIMIT 0,5
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # User func
        // Lấy tất cả người dùng
        function all_user(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_user
                INNER JOIN tb_loaiuser
                ON tb_user.idLoaiTK = tb_loaiuser.idLoaiTK
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy thông tin người dùng có idUser
        function info_user($idUser){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_user
                WHERE tb_user.idUser = :idUser
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idUser", $idUser, PDO::PARAM_INT);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # Loại user func
        // Lấy tất cả loại người dùng
        function all_tu(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_loaiuser
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy tất cả loại người dùng có id
        function info_tu($idLoaiTK){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_loaiuser
                WHERE idLoaiTK = :idLoaiTK
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idLoaiTK", $idLoaiTK, PDO::PARAM_INT);
            $pre->execute();
            return $pre->fetchAll();
        }
    #
    # Comment func
        // Lấy tất cả bình luận
        function all_cmt(){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_comment 
                INNER JOIN tb_user
                ON tb_comment.idUser = tb_user.idUser
                INNER JOIN tb_tintuc
                ON tb_comment.idTinTuc = tb_tintuc.idTinTuc
            ";
            $pre = $conn->prepare($sql);
            $pre->execute();
            return $pre->fetchAll();
        }
        // Lấy comment của 1 tin
        function cmt($idTinTuc){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_comment 
                INNER JOIN tb_user
                ON tb_comment.idUser = tb_user.idUser
                WHERE tb_comment.idTinTuc = :idTinTuc
                ORDER BY tb_comment.idCmt DESC
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":idTinTuc", $idTinTuc, PDO::PARAM_INT);
            $pre->execute();
            return $pre->fetchAll();
        }
        function dateDiff($date){
            $mydate= date("Y-m-d H:i:s");
            $theDiff=""; 
            $datetime1 = date_create($date);
            $datetime2 = date_create($mydate);
            $interval = date_diff($datetime1, $datetime2);
            $min=$interval->format('%i');
            $sec=$interval->format('%s');
            $hour=$interval->format('%h');
            $mon=$interval->format('%m');
            $day=$interval->format('%d');
            $year=$interval->format('%y');
            if($interval->format('%i%h%d%m%y')=="00000"){
                return $sec." giây trước";
            } 
            else if($interval->format('%h%d%m%y')=="0000"){
                return $min." phút trước";
            }
            else if($interval->format('%d%m%y')=="000"){
                return $hour." giờ trước";
            }
            else if($interval->format('%m%y')=="00"){
                return $day." ngày trước";
            }
            else if($interval->format('%y')=="0"){
                return $mon." tháng trước";
            }
            else{
                return $year." năm trước";
            }
        }
    #
    # Tìm kiếm func
        // Tìm kiếm tin có từ khóa
        function find($tk){
            require "ConDB.php";
            $sql = "
                SELECT * FROM tb_tintuc
                INNER JOIN tb_nguontin
                ON tb_tintuc.idNguonTin = tb_nguontin.idNguonTin
                INNER JOIN tb_loaitin
                ON tb_tintuc.idLoaiTin = tb_loaitin.idLoaiTin
                WHERE tb_tintuc.TieuDe REGEXP :tk
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":tk", $tk, PDO::PARAM_STR);
            $pre->execute();
            return $pre->fetchAll();
        }
    #

?>