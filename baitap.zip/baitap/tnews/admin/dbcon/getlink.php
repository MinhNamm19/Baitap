<?php 

function getBetween($content,$start,$end){ 
    $r = explode($start, $content);
	if (isset($r[1])){
		$r = explode($end, $r[1]);
		return $r[0];
	}
	return '';
}
function htmlEncode($videoUrl){ 

    $ch = curl_init($videoUrl); 
    
    curl_setopt( $ch, CURLOPT_POST, false ); 
    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true ); 
    curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6)    Gecko/20070725 Firefox/2.0.0.6"); 
    curl_setopt( $ch, CURLOPT_HEADER, false ); 
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); 
    $data = curl_exec( $ch ); 
    
    curl_close($ch); 
    $html_encoded = htmlentities($data);   
    return $html_encoded;
}
function videoFb($videoUrl){ 

    $ch = curl_init($videoUrl); 
    curl_setopt( $ch, CURLOPT_POST, false );
    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
    curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U;   Windows NT 5.0; en-US; rv:1.7.12) Gecko/20050915 Firefox/1.0.7");
    curl_setopt( $ch, CURLOPT_HEADER, false );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
    $data = curl_exec( $ch );
    curl_close($ch );
    $html_encoded = htmlentities($data);

    if (stripos($data,"hd_src:")!=false && stripos($data, "sd_src")!=false) {
        $start = 'hd_src:"';
        $end = '",sd_src';
        $videoHD = getBetween($data,$start,$end);
    }else {
        $videoHD = "";
    }
    if (stripos($data,"sd_src_no_ratelimit:")!=false && stripos($data, "aspect_ratio")!=false) {
        $start = 'sd_src_no_ratelimit:"';
        $end = '",aspect_ratio';
        $videoSD = getBetween($data,$start,$end);
    } else {
        $videoSD = "";
    }

    if($videoHD != ""){
        return $videoHD;
    }else{
        return $videoSD;
    }
    
}
function fembed($videoUrl){

    $ch = curl_init($videoUrl); 
    curl_setopt( $ch, CURLOPT_POST, false ); 
    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true ); 
    curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6)    Gecko/20070725 Firefox/2.0.0.6"); 
    curl_setopt( $ch, CURLOPT_HEADER, false ); 
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); 
    $data = curl_exec( $ch ); 
    curl_close($ch); 
    $html_encoded = htmlentities($data); 
    
    if (stripos($data,'https:\/\/www.fembed.com')!=false && stripos($data, '\"')!=false) { 
        $start = 'https:\/\/www.fembed.com'; 
        $end = '\"'; 
        $output = getBetween($data,$start,$end);
        $s = str_replace("\/", "/", $output);
        $s = "https://www.fembed.com".$s;
    }else if(stripos($data,'https:\/\/123phim.top')!=false && stripos($data, '\"')!=false) { 
        $start = 'https:\/\/123phim.top'; 
        $end = '\"'; 
        $output = getBetween($data,$start,$end);
        $s = str_replace("\/", "/", $output);
        $s = "https://123phim.top/".$s;
    }else {
        return "None!!!"; 
    }

    

    return $s;
}
function playhydrax($videoUrl){

    $ch = curl_init($videoUrl); 
    curl_setopt( $ch, CURLOPT_POST, false ); 
    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true ); 
    curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6)    Gecko/20070725 Firefox/2.0.0.6"); 
    curl_setopt( $ch, CURLOPT_HEADER, false ); 
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); 
    $data = curl_exec( $ch ); 
    curl_close($ch); 
    $html_encoded = htmlentities($data); 
    
    if (stripos($data,'https://playhydrax.com')!=false) { 
        $start = 'https://playhydrax.com'; 
        $end = '"'; 
        $output = getBetween($data,$start,$end);
    } else {
        return "None!!!"; 
    }

    // $s = str_replace("\/", "/", $output);
    $s = "https://playhydrax.com".$output;

    return $s;
}
function findS($data, $start, $end){

    if (stripos($data,"<iframe")!=false && stripos($data, "iframe>")!=false) { 
        $start = "<iframe"; 
        $end = "iframe>"; 
        $output = getBetween($data,$start,$end);
    } else {
        $output = "none"; 
    }
    return $output;
}

?>
