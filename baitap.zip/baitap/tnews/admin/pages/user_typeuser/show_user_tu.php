<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Cơ Sở Dữ Liệu</h1>
    <p class="mb-4">Quản lý các thông tin của trang web</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Quản lý người dùng và loại người dùng</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div class="row" style="padding: 0;margin: 0;">
                    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tài khoản</th>
                                    <th>Avatar</th>
                                    <th>Loại tài khoản</th>
                                    <th><i class="fa fa-cog" aria-hidden="true"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $user = all_user();
                                    foreach( $user as $u ):
                                ?>
                                    <tr>
                                        <td><?php echo $u["idUser"]; ?></td>
                                        <td><?php echo $u["TaiKhoan"]; ?></td>
                                        <td><img src="../public/img/user/<?php echo $u["img"]; ?>" alt="" width="50px"></td>
                                        <td><?php echo $u["Loai"]; ?></td>
                                        <td>
                                            <a href="./?p=sua-user&idUser=<?php echo $u["idUser"]; ?>">Sửa</a> | 
                                            <form action="././action/user_action.php" method="post" onsubmit='return confirm("Bạn có chắc là muốn xóa người dùng: <?php echo $u["TaiKhoan"]; ?> không ???")' style="display: inline;">
                                                <input type="hidden" name="idUser" value="<?php echo $u["idUser"]; ?>">
                                                <button type="submit" name="xoa" class="btn-delete">Xóa</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php
                                    endforeach;
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Loại</th>
                                    <th><a href="./?p=add-typeuser">Thêm</a></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $type = all_tu();
                                    foreach($type as $t):
                                ?>
                                    <tr>
                                        <td><?php echo $t["idLoaius"]; ?></td>
                                        <td><?php echo $t["Loai"]; ?></td>
                                        <td>
                                            <a href="./?p=sua-typeuser&idLoaius=<?php echo $t["idLoaius"]; ?>">Sửa</a> | 
                                            <form action="././action/typeuser_action.php" method="post" onsubmit='return confirm("Bạn có chắc là muốn xóa loại: <?php echo $t["Loai"]; ?> không ???")' style="display: inline;">
                                                <input type="hidden" name="idLoaius" value="<?php echo $t["idLoaius"]; ?>">
                                                <button type="submit" name="xoa" class="btn-delete">Xóa</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php
                                    endforeach;
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
</div>

