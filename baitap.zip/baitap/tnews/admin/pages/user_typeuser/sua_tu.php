<?php
    if( isset($_GET["idLoaius"]) ){
        $type = info_tu((int)$_GET["idLoaius"]);
    }
    foreach( $type as $t ):
?>

<div class="container-fluid">

    <h1 class="h3 mb-2 text-gray-800">Loại Người Dùng: <span><?php echo $t["Loai"]; ?></span></h1>
    
    <div class="add-item"> 
        <form action="././action/typeuser_action.php" method="post" style="" enctype='multipart/form-data'>
            <label for="tu">Loại người dùng:</label>
            <input type="text" name="tu" class="form-control form-control-sm in-s" value="<?php echo $t["Loai"]; ?>">
            <input type="hidden" name="idLoaius"  value="<?php echo $t["idLoaius"]; ?>"> <br>
            <button type="submit" class="btn-sub" name="sua" data-toggle="modal" data-target="#myModal">Sửa</button>
        </form>
    </div>
</div>
<script>
    
</script>
<?php
    endforeach;
?>