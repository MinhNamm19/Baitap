<?php
    if( isset($_GET["idTl"]) ){
        $theloai = theloai_phim((int)$_GET["idTl"]);
    }
    foreach( $theloai as $t ):
?>

<div class="container-fluid">

    <h1 class="h3 mb-2 text-gray-800">Chỉnh Sửa Thể Loại: <?php echo $t["TheLoai"]; ?></h1>
    
    <div class="add-item">
        <form action="././action/theloai_action.php" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
            <label for="theloai">Thể loại: </label>
            <input type="text" name="theloai" id="" class="form-control form-control-sm in-s" value="<?php echo $t["TheLoai"]; ?>">
            <br>
            <input type="hidden" value="<?php echo $_GET["idTl"]; ?>" name="idTl">
            <button type="submit" class="btn-sub" name="sua" data-toggle="modal" data-target="#myModal">Sửa</button>
        </form>
    </div>
    <div id="myModal"  class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body" id="popup">
                    <p id="popup">Chờ 1 tí ....</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
<?php
    endforeach;
?>