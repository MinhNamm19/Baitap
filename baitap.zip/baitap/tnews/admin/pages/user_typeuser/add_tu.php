<div class="container-fluid">

    <h1 class="h3 mb-2 text-gray-800">Thêm Thể Loại Người Dùng</h1>
    
    <div class="add-item">
        <form action="././action/typeuser_action.php" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
            <label for="tu">Thể loại người dùng: </label>
            <input type="text" name="tu" id="" class="form-control form-control-sm in-s">
            <br>
            <button type="submit" class="btn-sub" name="add" data-toggle="modal" data-target="#myModal">Thêm</button>
        </form>
    </div>
    <div id="myModal"  class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body" id="popup">
                    <p id="popup">Chờ 1 tí ....</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>