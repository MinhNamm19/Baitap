<?php
    require "../../dbcon/function.php";
    require "../../dbcon/ConDB.php";
    $idTinTuc = $_GET["idTinTuc"];
    $content = "";
    foreach(info_new($idTinTuc) as $row){
        $content = $row["NoiDung"];
    }
    echo $content;
?>
