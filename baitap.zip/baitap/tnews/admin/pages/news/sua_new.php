<?php
    if( isset($_GET["idTinTuc"]) ){
        $tin = info_new((int)$_GET["idTinTuc"]);
    }
    foreach( $tin as $row ):
?>

<div class="container-fluid">

    <a href="./?p=show-news">Quay lại</a>
    <h1 class="h3 mb-2 text-gray-800">Thông Tin:</h1>
    <div class="add-item">
        <form action="././action/new_action.php" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
            <input type="hidden" name="id" value="<?php echo $row["idTinTuc"]; ?>">

            <label for="tieude">Tiêu đề: </label>
            <input type="text" name="tieude" class="form-control form-control-sm in" value="<?php echo $row["TieuDe"]; ?>"> <br>

            <label for="tieudekd">Tiêu đề không dấu: </label>
            <input type="text" name="tieudekd" class="form-control form-control-sm in" value="<?php echo $row["TieuDeKD"]; ?>"> <br>

            <label for="noidung">Nội dung: </label>
            <textarea id="demo" class="ckeditor" name="noidung"><?php echo $row["NoiDung"]; ?></textarea> <br>
            
            <label for="luotxem">Lượt xem: </label>
            <input type="number" name="luotxem" class="form-control form-control-sm in-s" value="<?php echo $row["LuotXem"]; ?>" min="0"> <br>

            <label for="loaitin">Loại tin: </label>
            <select name="loaitin" class="form-control form-control-sm in-s" style="width: 150px">
                <?php
                    foreach( all_loaitin() as $n ):
                ?>
                <option value="<?php echo $n["idLoaiTin"]; ?>" <?php if($row["idLoaiTin"] === $n["idLoaiTin"]){echo "selected";} ?>><?php echo $n["LoaiTin"]; ?></option>
                <?php
                    endforeach;
                ?>
            </select>
            <br>

            <label for="nguontin">Nguồn tin: </label>
            <select name="nguontin" class="form-control form-control-sm in-s" style="width: 150px">
                <?php
                    foreach( all_nguontin() as $n ):
                ?>
                <option value="<?php echo $n["idNguonTin"]; ?>" <?php if($row["idNguonTin"] === $n["idNguonTin"]){echo "selected";} ?>><?php echo $n["NguonTin"]; ?></option>
                <?php
                    endforeach;
                ?>
            </select>
            <br>

            <label for="img">Ảnh minh họa: </label>
            <input type="file" name="img" id="img" /> 
            <span>Đề nghị: ngang 270px, dọc 350px đuôi file là jpg hoặc jpeg</span>
            <input type="hidden" name="anhmh" value="<?php echo $row["AnhMH"]; ?>">
            <p><img src="../public/img/news/<?php echo $row["AnhMH"]; ?>" width="350px" alt="" srcset=""></p>
            <br>

            <label for="nguondang">Người đăng: </label>
            <input type="text" name="nguondang" value="<?php echo $row["TaiKhoan"]; ?>" disabled> <br>

            <button type="submit" class="btn-sub" name="sua">Sửa</button>
        </form>
    </div>
</div>
<script>
    
</script>
<?php
    endforeach;
?>