<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Cơ Sở Dữ Liệu</h1>
    <p class="mb-4">Quản lý các thông tin của trang web</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Quản lý tin tức</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tiêu đề</th>
                            <th>Nội dung</th>
                            <th>Ảnh minh họa</th>
                            <th>Loại tin</th>
                            <th>Ngày đăng</th>
                            <th>Nguồn tin</th>
                            <th>Người đăng</th>
                            <th id="ac"><a href="javascript:void(0)" onclick="document.getElementById('add-news').style.display='block'">THÊM</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $news = all_news();
                            foreach( $news as $new ):
                            
                        ?>
                        <tr>
                            <td><?php echo $new["idTinTuc"]; ?></td>
                            <td ><?php echo $new["TieuDe"]; ?></td>
                            <td><a href="javascript:void(0)" data-id="<?php echo $new["idTinTuc"]; ?>" onclick="getContent(this)">Bấm để xem nội dung</a></td>
                            <td><img src="../public/img/news/<?php echo $new["AnhMH"]; ?>" alt="<?php echo $new["TieuDeKD"]; ?>" width="85px"></td>
                            <td><?php echo $new["LoaiTin"]; ?></td>
                            <td><?php echo $new["NgayDang"]; ?></td>
                            <td><?php echo $new["NguonTin"]; ?></td>
                            <td><?php echo $new["TaiKhoan"]; ?></td>
                            <td>
                                <a href="./?p=sua-new&idTinTuc=<?php echo $new["idTinTuc"]; ?>" title="Sửa tin tức">Sửa</a> |
                                <form action="././action/new_action.php" 
                                    onsubmit='return confirm("Bạn có chắc là muốn xóa tin: <?php echo $new["TieuDe"]; ?> không ???")' method="post">
                                    <input type="hidden" name="idTinTuc" value="<?php echo $new["idTinTuc"]; ?>">
                                    <input type="hidden" name="img" value="<?php echo $new["AnhMH"]; ?>">
                                    <button class="btn-delete" type="submit" title="xóa tin" name="xoa">Xóa</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                            endforeach;
                        ?>
                    </tbody>
                </table>

                <!-- Thêm tin -->
                <div id="add-news" class="modal">
                    <form action="././action/new_action.php" class="modal-content animate" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
                        <div class="form form-them-phim">
                            <span onclick="document.getElementById('add-news').style.display='none'" class="close" title="Close Modal">&times;</span>
                            <h4>Thêm Tin Tức</h4>

                            <label for="tieude">Tiêu đề: </label>
                            <input type="text" name="tieude" class="form-control form-control-sm in"> <br>

                            <label for="noidung">Nội dung: </label>
                            <textarea id="demo" class="ckeditor" name="noidung"></textarea> <br>

                            <label for="luotxem">Lượt xem: </label>
                            <input type="number" name="luotxem" class="form-control form-control-sm in-s" value="0" min="0"> <br>

                            <label for="loaitin">Loại tin: </label>
                            <select name="loaitin" class="form-control form-control-sm in" style="width: 150px">
                                <?php
                                    foreach( all_loaitin() as $row ):
                                ?>
                                <option value="<?php echo $row["idLoaiTin"]; ?>"><?php echo $row["LoaiTin"]; ?></option>
                                <?php
                                    endforeach;
                                ?>
                            </select>
                            <br>

                            <label for="nguontin">Nguồn tin: </label>
                            <select name="nguontin" class="form-control form-control-sm in" style="width: 150px">
                                <?php
                                    foreach( all_nguontin() as $row ):
                                ?>
                                <option value="<?php echo $row["idNguonTin"]; ?>"><?php echo $row["NguonTin"]; ?></option>
                                <?php
                                    endforeach;
                                ?>
                            </select>
                            <br>

                            <label for="img">Ảnh minh họa: </label>
                            <input type="file" name="img" id="img" /> 
                            <span>Đề nghị: ngang 270px, dọc 350px đuôi file là jpg hoặc jpeg</span>
                            <br>

                            <input type="hidden" name="idUser" value="1">
                            <button type="submit" class="btn-sub" name="add">Thêm</button>
                        </div>
                    </form>
                </div>

                <!-- Xem nội dung -->
                <div id="view-content" class="modal">
                    <div class="modal-content animate">
                        <div class="form view-content">
                            <span onclick="document.getElementById('view-content').style.display='none'" class="close" title="Close Modal">&times;</span>
                            <div id="noidung"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>


