<?php
    require "../../dbcon/function.php";
    $idUser = (int)$_GET["idUser"];
    foreach(info_user($idUser) as $row):
?> 
<form action="././action/user_action.php" class="modal-content animate" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
    <div class="form">
        <span onclick="document.getElementById('sua-loai').style.display='none'" class="close" title="Close Modal">&times;</span>
        <h4>Sửa loại tài khoản</h4>
        <label>Tài Khoản: </label>
        <input type="text" value="<?php echo $row["TaiKhoan"]; ?>" disabled class="form-control form-control-sm in">
        <br>
        <label >Loại:</label>
        <select name="idLoai" class="form-control form-control-sm in">
            <?php
                $types = all_tu();
                foreach($types as $type):
            ?>
                <option value="<?php echo $type["idLoaiTK"]; ?>" <?php if($type["idLoaiTK"] == $row["idLoaiTK"]){echo "selected";} ?>><?php echo $type["LoaiTK"]; ?></option>
            <?php
                endforeach;
            ?>
        </select> <br>
        <input type="hidden" name="idUser" value="<?php echo $idUser; ?>">
        <button type="submit" class="btn-sub" name="sua-loai">Sửa</button>
    </div>
</form>
<?php endforeach; ?>