<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Cơ Sở Dữ Liệu</h1>
    <p class="mb-4">Quản lý các thông tin của trang web</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Quản lý người dùng</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tài khoản</th>
                            <th>Email</th>
                            <th>Ảnh</th>
                            <th>Loại</th>
                            <th><img src="https://img.icons8.com/dusk/20/000000/gear.png"/></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $users = all_user();
                            foreach($users as $user):
                        ?>
                            <tr>
                                <td><?php echo $user["idUser"]; ?></td>
                                <td><?php echo $user["TaiKhoan"]; ?></td>
                                <td><?php echo $user["Email"]; ?></td>
                                <td><img src="../public/img/user/<?php echo $user["Avatar"]; ?>" alt="" srcset="" width="50px"></td>
                                <td>
                                    <?php
                                        if($user["idUser"] != 1):
                                    ?>
                                        <a href="javascript:void(0)" style="
                                            <?php
                                                if($user["idLoaiTK"] == 1){
                                                    echo "color:red;";
                                                }
                                                if($user["idLoaiTK"] == 2){
                                                    echo "color:green;";
                                                }
                                            ?>
                                        " onclick="changeType(this)" data-iduser="<?php echo $user["idUser"]; ?>">
                                            <?php echo $user["LoaiTK"]; ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if($user["idUser"] === 1){ echo $user["LoaiTK"]; } ?>
                                </td>
                                <td> 
                                    <?php
                                        if($user["idUser"] != 1):
                                    ?>
                                    <form action="././action/user_action.php" method="post" onsubmit='return confirm("Bạn có chắc là muốn xóa người dùng: <?php echo $user["TaiKhoan"]; ?> không ???")' style="display: inline;">
                                        <input type="hidden" name="idUser" value="<?php echo $user["idUser"]; ?>">
                                        <button type="submit" name="xoa" class="btn-delete">Xóa</button>
                                    </form>
                                    <?php
                                        endif;
                                    ?>
                                </td>
                            </tr>
                        <?php
                            endforeach;
                        ?>
                    </tbody>
                </table>

                <!-- Sửa loại người dùng -->
                <div id="sua-loai" class="modal">
                </div>
            </div>
        </div>
    </div>

    
</div>

