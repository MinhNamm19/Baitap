<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Cơ Sở Dữ Liệu</h1>
    <p class="mb-4">Quản lý các thông tin của trang web</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Quản lý loại tin</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Danh Mục</th>
                            <th><a href="javascript:void(0)" onclick="document.getElementById('add-dm').style.display='block'">Thêm</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach( all_danhmuc() as $row ):
                        ?>
                            <tr>
                                <td><?php echo $row["idDanhMuc"]; ?></td>
                                <td><?php echo $row["DanhMuc"]; ?></td>
                                <td>
                                    <form action="././action/danhmuc_action.php" method="post" style="display: inline;" 
                                        onsubmit='return confirm("Bạn hãy chắc là danh mục <?php echo $row["DanhMuc"]; ?> không chứa loại tin nào !!!")'>
                                        <input type="hidden" name="idDanhMuc" value="<?php echo $row["idDanhMuc"]; ?>">
                                        <button type="submit" name="xoa" class="btn-delete">Xóa</button>
                                    </form>
                                </td>
                            </tr>
                        <?php
                            endforeach;
                        ?>
                    </tbody>
                </table>

                <!-- Thêm danh mục -->
                <div id="add-dm" class="modal">
                    <form action="././action/danhmuc_action.php" class="modal-content animate" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
                        <div class="form form-them-phim">
                            <span onclick="document.getElementById('add-dm').style.display='none'" class="close" title="Close Modal">&times;</span>
                            <h4>Thêm Danh Mục</h4>

                            <label for="danhmuc">Danh mục: </label>
                            <input type="text" name="danhmuc" class="form-control form-control-sm in"> <br>

                            <button type="submit" class="btn-sub" name="add">Thêm</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    
</div>

