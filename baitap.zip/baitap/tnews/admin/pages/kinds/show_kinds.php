<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Cơ Sở Dữ Liệu</h1>
    <p class="mb-4">Quản lý các thông tin của trang web</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Quản lý loại tin</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Loại tin</th>
                            <th><a href="javascript:void(0)" onclick="document.getElementById('add-kind').style.display='block'">Thêm</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach( all_loaitin() as $row ):
                        ?>
                            <tr>
                                <td><?php echo $row["idLoaiTin"]; ?></td>
                                <td><?php echo $row["LoaiTin"]; ?></td>
                                <td>
                                    <form action="././action/kind_action.php" method="post" style="display: inline;" 
                                        onsubmit='return confirm("Bạn có chắc là muốn xóa loại tin: <?php echo $row["LoaiTin"]; ?> này không ???")'>
                                        <input type="hidden" name="idLoaiTin" value="<?php echo $row["idLoaiTin"]; ?>">
                                        <button type="submit" name="xoa" class="btn-delete">Xóa</button>
                                    </form>
                                </td>
                            </tr>
                        <?php
                            endforeach;
                        ?>
                    </tbody>
                </table>

                <!-- Thêm loại tin -->
                <div id="add-kind" class="modal">
                    <form action="././action/kind_action.php" class="modal-content animate" method="post" style="margin-top:25px;" enctype='multipart/form-data'>
                        <div class="form form-them-phim">
                            <span onclick="document.getElementById('add-kind').style.display='none'" class="close" title="Close Modal">&times;</span>
                            <h4>Thêm Loại Tin</h4>

                            <label for="loaitin">Loại tin: </label>
                            <input type="text" name="loaitin" class="form-control form-control-sm in"> <br>

                            <label for="danhmuc">Danh mục: </label>
                            <select name="danhmuc" class="form-control form-control-sm in" style="width: 150px">
                                <?php
                                    foreach( all_danhmuc() as $row ):
                                ?>
                                <option value="<?php echo $row["idDanhMuc"]; ?>"><?php echo $row["DanhMuc"]; ?></option>
                                <?php
                                    endforeach;
                                ?>
                            </select>
                            <br>

                            <button type="submit" class="btn-sub" name="add">Thêm</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    
</div>

