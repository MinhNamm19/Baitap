$(document).ready(function(){
    $("#slide-4").hover(function(){
        $("#thong-tin").animate({bottom:'0'},500);
    }, function(){
        $("#thong-tin").animate({bottom:'-170px'},100);
    });
    $("#slide-1").hover(function(){
        $("#tt-1").animate({left:'0'},500);
    }, function(){
        $("#tt-1").animate({left:'-100%'},100);
    });
    $("#slide-2").hover(function(){
        $("#tt-2").animate({left:'0'},500);
    }, function(){
        $("#tt-2").animate({left:'-100%'},100);
    });
    $("#slide-3").hover(function(){
        $("#tt-3").animate({left:'0'},500);
    }, function(){
        $("#tt-3").animate({left:'-100%'},100);
    });
    $("#slide-5").hover(function(){
        $("#tt-5").animate({left:'0'},500);
    }, function(){
        $("#tt-5").animate({left:'-100%'},100);
    });
    $("#slide-6").hover(function(){
        $("#tt-6").animate({left:'0'},500);
    }, function(){
        $("#tt-6").animate({left:'-100%'},100);
    });
    $("#slide-7").hover(function(){
        $("#tt-7").animate({left:'0'},500);
    }, function(){
        $("#tt-7").animate({left:'-100%'},100);
    });

    // ——————————————————————————————————————————————————
    // chạy chữ footer
    // ——————————————————————————————————————————————————

    class TextScramble {
        constructor(el) {
        this.el = el
        this.chars = '!<>-_\\/[]{}—=+*^?#________'
        this.update = this.update.bind(this)
        }
        setText(newText) {
        const oldText = this.el.innerText
        const length = Math.max(oldText.length, newText.length)
        const promise = new Promise((resolve) => this.resolve = resolve)
        this.queue = []
        for (let i = 0; i < length; i++) {
            const from = oldText[i] || ''
            const to = newText[i] || ''
            const start = Math.floor(Math.random() * 40)
            const end = start + Math.floor(Math.random() * 40)
            this.queue.push({ from, to, start, end })
        }
        cancelAnimationFrame(this.frameRequest)
        this.frame = 0
        this.update()
        return promise
        }
        update() {
        let output = ''
        let complete = 0
        for (let i = 0, n = this.queue.length; i < n; i++) {
            let { from, to, start, end, char } = this.queue[i]
            if (this.frame >= end) {
            complete++
            output += to
            } else if (this.frame >= start) {
            if (!char || Math.random() < 0.28) {
                char = this.randomChar()
                this.queue[i].char = char
            }
            output += `<span class="dud">${char}</span>`
            } else {
            output += from
            }
        }
        this.el.innerHTML = output
        if (complete === this.queue.length) {
            this.resolve()
        } else {
            this.frameRequest = requestAnimationFrame(this.update)
            this.frame++
        }
        }
        randomChar() {
        return this.chars[Math.floor(Math.random() * this.chars.length)]
        }
    } 
    const phrases = [
        'kanime',
        'version: 1.0.3',
        'kanime.contact@gmail.com'
    ];
    
    const el = document.querySelector('.text');
    const fx = new TextScramble(el);
    
    let counter = 0;
    const next = () => {
        fx.setText(phrases[counter]).then(() => {
        setTimeout(next, 1000)
        });
        counter = (counter + 1) % phrases.length;
    }
    next();

    

    const search = document.getElementById("tk");
    const matchlist = document.getElementById("match-list");

    const searchStates = async searchText => {
        const res = await fetch('http://kanime.cf/service/anime/');
        const states = await res.json();

        // 
        let matches = states.filter(state => {
            const regex = new RegExp(`^${searchText}`, 'gi');
            return state.name.match(regex);
        });

        //console.log(matches);

        if(searchText.length < 3){
            matches = [];
            matchlist.innerHTML = '';
        }
        outputHtml(matches);
    };

    const outputHtml = matches => {
        if(matches.length > 0){
            const html = matches.map(match => `
                <div class="list-movie">
                    <a href="thong-tin/${match.id}-${match.dname}.html">
                        <img src="public/img/bia/${match.bia}" alt="">
                        <h4>${match.name}</h4>
                        <p>${match.oname}</p>
                        <p>Lượt xem: ${match.view}</p>
                    </a>
                </div>
            `).join('');
            matchlist.innerHTML = html;
        }
    };


    search.addEventListener('input', () => searchStates(search.value));

    
    
});
function openNav() {
    document.getElementById("mySidepanel").style.width = "300px";
}
function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
}
function rotateRegis() {
    document.getElementById("abc").style.transform = "rotateX(180deg)";
    document.getElementById('regis-mb').style.display = 'block';
    document.getElementById('login-mb').style.display = 'none';
}
function rotateLogin() {
    document.getElementById("abc").style.transform = "none";
    document.getElementById('login-mb').style.display = 'block';
    document.getElementById('regis-mb').style.display = 'none';

}
function listDown(ele) {
    const status = ele.getAttribute("data-show");
    if (status == 0) {
        $("#ua-item").animate({ top: '55px' }, 500);
        $(ele).attr("data-show", "1");
    }
    if (status == 1) {
        $("#ua-item").animate({ top: '-55px' }, 100);
        $(ele).attr("data-show", "0");
    }
}
function abc() {
    const signUpButton = document.getElementById('signUp');
    const signInButton = document.getElementById('signIn');
    const container = document.getElementById('container');

    signUpButton.addEventListener('click', () => {
        container.classList.add('right-panel-active');
    });

    signInButton.addEventListener('click', () => {
        container.classList.remove('right-panel-active');
    });
}
abc();
function changeServer(ele){
    $("#if").html('<div id="iframe-loading"><img src="public/img/loading.gif" alt=""></div>');
    const url = ele.getAttribute("data-url");
    const server = ele.getAttribute("data-id");
    $(".ser").attr("style","");
    ele.setAttribute("style", "color:aqua;");
    $.get("user_action/change_server.php", {url:url, server:server}, function(data){
        $("#if").html(data);
    });
}