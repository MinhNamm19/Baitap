const reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var tk = false;
var mk = false;
var a = false;
function setErro(input, mess) {
    var formc = input.parentElement;
    var tb = formc.querySelector("p");
    tb.innerHTML = mess;
    formc.className = "control erro";
}

function setSucc(input, mess) {
    var formc = input.parentElement;
    var tb = formc.querySelector("p");
    tb.innerHTML = mess;
    formc.className = "control succ";
}

function checkLogin(){
    var tdnv = document.getElementById("tdn");
    var pwv = document.getElementById("pw");

    if (tdnv.value !== "" && pwv.value !== "") {
        return true;
    }
    return false;
}



function checkErroRegis(){
    const eml = document.getElementById("eml");
    const tdndk = document.getElementById("tdndk");
    const pwdk = document.getElementById("pwdk");
    const rpwdk = document.getElementById("rpwdk");

    eml.addEventListener('blur', (e) => {
        const val = e.target.value;
        if (val === "") {
            setErro(eml, "Email trống !!!");
        } 
    });
    
    eml.addEventListener('keyup', (e) => {
        const val = eml.value;
        if (val === "") {
            setErro(eml, "Email trống !!!");
        } else if (reg.test(val) !== true) {
            setErro(eml, "Email không đúng định dạng !!!");
        } else {
            setSucc(eml, "");
            a = true;
        }
    });

    tdndk.addEventListener('blur', (e) => {
        const val = e.target.value;
        if (val === "") {
            setErro(tdndk, "Tên đăng nhập trống");
        }
    });
    tdndk.addEventListener('keyup', (e) => {
        const val = tdndk.value;
        if (val === "") {
            setErro(tdndk, "Tên đăng nhập trống");
        }
        if (val.length <= 6) {
            setErro(tdndk, "Tên đăng nhập phải lớn hơn 6 ký tự");
        }else {
            setSucc(tdndk, "");
            tk = true;
        }
    });

    pwdk.addEventListener('blur', (e) => {
        const val = e.target.value;
        if (val === "") {
            setErro(pwdk, "Mật khẩu trống");
        }

    });
    pwdk.addEventListener('keyup', (e) => {
        const val = pwdk.value;
        if (val === "") {
            setErro(pwdk, "Mật khẩu trống");
        }  
        if (val.length <= 6) {
            setErro(pwdk, "Mật khẩu phải lớn hơn 6 ký tự");
        }else {
            setSucc(pwdk, "");
        }

    });

    rpwdk.addEventListener('blur', (e) => {
        const val = e.target.value;
        if (val === "") {
            setErro(rpwdk, "Nhập lại mật khẩu trống");
        } 
    });
    rpwdk.addEventListener('keyup', (e) => {
        const val = rpwdk.value;
        const pwdk1 = pwdk.value;
        if (val === "") {
            setErro(rpwdk, "Nhập lại mật khẩu trống");
        } else if (val !== pwdk1) {
            setErro(rpwdk, "Mật khẩu không trùng khớp");
            setErro(pwdk, "Mật khẩu không trùng khớp")
        } else {
            setSucc(pwdk, "");
            setSucc(rpwdk, "");
            mk = true;
        }
    });
    
}
checkErroRegis();

function checkRegis(){
    if(tk === true && mk === true){
        alert("Đăng ký thành công");
        return true;
    }
    return false;
}