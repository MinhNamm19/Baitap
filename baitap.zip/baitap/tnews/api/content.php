<?php
    require_once './c.php';
    class Content{
        function GetContent(){
            $content = "";
            $idTin = $_GET["idTin"];
            foreach(info_new($idTin) as $row){
                $content = $row["NoiDung"];
            }
            return $content;
        }
    }

    $a = new Content();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            padding:0;
        }
        img{
            width:100%;
        }
    </style>
</head>
<body>
    <?php echo $a->GetContent(); ?>
</body>
</html>