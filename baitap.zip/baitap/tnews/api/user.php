<?php
    require_once 'c.php';
    class User{
        function GetInfo(){
            $user = array();
            $idUser = $_GET["idUser"];
            foreach(info_user($idUser) as $row){
                $user[] = array(
                    'id'    => $row["idUser"],
                    'user-name'  => $row["TaiKhoan"],
                    'email' => $row["Email"],
                    'avatar'   => "http://".$_SERVER['SERVER_NAME']."/public/img/user/".$row["Avatar"]
                );
            }
            return json_encode($user);
        }

    }

    $user = new User();
    header('Content-Type', 'application/json');
    echo $user->GetInfo();
?>