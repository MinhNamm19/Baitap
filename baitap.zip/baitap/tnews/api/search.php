<?php
    require_once 'c.php';
    class Search{
        function GetAll(){
            $q = $_GET["q"];
            $news = array();
            foreach(find($q) as $row){
                $news[] = array(
                    'id' => $row["idTinTuc"],
                    'title' => $row["TieuDe"],
                    'ngaydang' => dateDiff($row["NgayDang"]),
                    'nguon' => $row["NguonTin"],
                    'loai' => $row["LoaiTin"],
                    'img' => "http://".$_SERVER['SERVER_NAME']."/public/img/news/".$row["AnhMH"]
                );
            }
            return json_encode($news);
        }
    }

    $search = new Search();
    header('Content-Type', 'application/json');
    echo $search->GetAll();
?>