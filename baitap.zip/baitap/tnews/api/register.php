<?php
    require_once 'c.php';
    if($_POST["email"] !==  "" && $_POST["tdn"] !==  "" && $_POST["pass"] !==  "" && $_POST["repass"] !==  ""){
        if($_POST["pass"] === $_POST["pass"]){
            $eml = $_POST["email"];
            $tdn = $_POST["tdn"];
            $pw = $_POST["pass"];
            $sql = "
                SELECT idUser FROM tb_user
                WHERE TaiKhoan = :tdn OR Email = :eml
            ";
            $pre = $conn->prepare($sql);
            $pre->bindParam(":tdn", $tdn, PDO::PARAM_STR);
            $pre->bindParam(":eml", $eml, PDO::PARAM_STR);
            $pre->execute();
            $count = $pre->rowCount();
            if( $count === 0){
                $sql = "
                    INSERT INTO tb_user (idUser, TaiKhoan, Email, MatKhau, Avatar, idLoaiTK) 
                    VALUES (NULL, :tdn, :eml, :pw, 'unknow.jpg', '2');
                ";
                $pre = $conn->prepare($sql);
                $pre->bindParam(":eml", $eml, PDO::PARAM_STR);
                $pre->bindParam(":tdn", $tdn, PDO::PARAM_STR);
                $pre->bindParam(":pw", $pw, PDO::PARAM_STR);
                $pre->execute();
                echo "true";
                
            }else{
                echo 'false';
            }
        }
    }
?>