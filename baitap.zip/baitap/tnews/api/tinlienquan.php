<?php
    require_once 'c.php';
    class TinLQ {
        function GetTLQ(){
            $news = array();
            $idLoaiTin = $_GET["idLoaiTin"];
            foreach(news_lienquan($idLoaiTin) as $row){
                $news[] = array(
                    'id' => $row["idTinTuc"],
                    'title' => $row["TieuDe"],
                    'ngaydang' => dateDiff($row["NgayDang"]),
                    'nguon' => $row["NguonTin"],
                    'loai' => $row["LoaiTin"],
                    'img' => "http://".$_SERVER['SERVER_NAME']."/public/img/news/".$row["AnhMH"]
                );
            }
            return json_encode($news);
        }
    }

    $news = new TinLQ();
    header('Content-Type', 'application/json');
    echo $news->GetTLQ();
?>