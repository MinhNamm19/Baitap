<?php
    require_once 'c.php';
    class Comment{
        function GetAll(){
            $cmt = array();
            $idTinTuc = $_GET["idTinTuc"];
            foreach(cmt($idTinTuc) as $row){
                $cmt[] = array(
                    'id-cmt'    => $row["idCmt"],
                    'user-name'    => $row["TaiKhoan"],
                    'content'  => $row["NoiDung"],
                    'date' => dateDiff($row["ThoiGian"]),
                    'img'   => "http://".$_SERVER['SERVER_NAME']."/public/img/user/".$row["Avatar"]
                );
            }
            return json_encode($cmt);
        }
    }

    $comment = new Comment();
    header('Content-Type', 'application/json');
    echo $comment->GetAll();
?>