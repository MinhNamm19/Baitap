<?php
    require_once 'c.php';
    if($_POST["tdn"] !==  "" && $_POST["pass"] !==  ""){
        $tdn = $_POST["tdn"];
        $pw = $_POST["pass"];
        $sql = "
            SELECT * FROM tb_user
            WHERE TaiKhoan = :tdn OR Email = :tdn
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":tdn", $tdn, PDO::PARAM_STR);
        $pre->execute();
        if($pre->rowCount() !== 0){
            $acc = $pre->fetchAll();
            foreach($acc as $row){
                if ($pw == $row["MatKhau"]) {
                    echo $row["idUser"];
                }else {
                    echo "false";
                }
            }
        }
        
    }
?>