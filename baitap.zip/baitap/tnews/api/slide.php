<?php
    require_once 'c.php';
    class Slide {
        function GetAll(){
            $news = array();
            foreach(all_slide() as $row){
                $news[] = array(
                    'id' => $row["idTinTuc"],
                    'title' => $row["TieuDe"],
                    'ngaydang' => $row["NgayDang"],
                    'nguon' => $row["NguonTin"],
                    'img' => "http://".$_SERVER['SERVER_NAME']."/public/img/news/".$row["AnhMH"]
                );
            }
            return json_encode($news);
        }
    }

    $slide = new Slide();
    header('Content-Type', 'application/json');
    echo $slide->GetAll();
?>