<?php
    require_once 'c.php';
    class Tech {
        function GetNews(){
            $news = array();
            $idLoaiTin = $_GET["idLoaiTin"];
            foreach(news_tech($idLoaiTin) as $row){
                $news[] = array(
                    'id' => $row["idTinTuc"],
                    'title' => $row["TieuDe"],
                    'ngaydang' => dateDiff($row["NgayDang"]),
                    'nguon' => $row["NguonTin"],
                    'loai' => $row["LoaiTin"],
                    'img' => "http://".$_SERVER['SERVER_NAME']."/public/img/news/".$row["AnhMH"]
                );
            }
            return json_encode($news);
        }
    }

    $news = new Tech();
    header('Content-Type', 'application/json');
    echo $news->GetNews();
?>