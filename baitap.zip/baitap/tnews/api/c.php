<?php
    require_once "../admin/dbcon/function.php";
    require_once "../admin/dbcon/ConDB.php";
?>