<?php
    require_once 'c.php';
    class HotNews {
        function GetHotNews(){
            $news = array();
            foreach(hot_news() as $row){
                $news[] = array(
                    'id' => $row["idTinTuc"],
                    'title' => $row["TieuDe"],
                    'ngaydang' => dateDiff($row["NgayDang"]),
                    'nguon' => $row["NguonTin"],
                    'loai' => $row["LoaiTin"],
                    'view' => $row["LuotXem"],
                    'img' => "http://".$_SERVER['SERVER_NAME']."/public/img/news/".$row["AnhMH"]
                );
            }
            return json_encode($news);
        }
    }

    $news = new HotNews();
    header('Content-Type', 'application/json');
    echo $news->GetHotNews();
?>