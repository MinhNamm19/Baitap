<?php
    require_once 'c.php';
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $date = date("Y-m-d H:i:s");
    if(isset($_POST["cmt"])){
        $cmt = $_POST["cmt"];
        $idUser = $_POST["idUser"];
        $idTinTuc = $_POST["idTinTuc"];
        $sql = "
            INSERT INTO tb_comment (idCmt, idUser, idTinTuc, NoiDung, ThoiGian) 
            VALUES (NULL, :idUser, :idTinTuc, :cmt, :date);
        ";
        $pre = $conn->prepare($sql);
        $pre->bindParam(":cmt", $cmt, PDO::PARAM_STR);
        $pre->bindParam(":idUser", $idUser, PDO::PARAM_INT);
        $pre->bindParam(":idTinTuc", $idTinTuc, PDO::PARAM_INT);
        $pre->bindParam(":date", $date);
        $pre->execute();
        echo "success";
    }else {
        echo "failure";
    }
?>