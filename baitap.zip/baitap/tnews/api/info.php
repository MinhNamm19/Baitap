<?php
    require_once 'c.php';
    class Info {
        function GetInfo(){
            $new = array();
            $idTin = $_GET["idTin"];
            foreach(info_new($idTin) as $row){
                $news[] = array(
                    'id' => $row["idTinTuc"],
                    'title' => $row["TieuDe"],
                    'ngaydang' => dateDiff($row["NgayDang"]),
                    'nguon' => $row["NguonTin"],
                    'loai' => $row["LoaiTin"],
                    'idloai' => $row["idLoaiTin"],
                    'view' => $row["LuotXem"],
                    'img' => "http://".$_SERVER['SERVER_NAME']."/public/img/news/".$row["AnhMH"]
                );
            }
            return json_encode($news);
        }
    }

    $new = new Info();
    header('Content-Type', 'application/json');
    echo $new->GetInfo();
?>